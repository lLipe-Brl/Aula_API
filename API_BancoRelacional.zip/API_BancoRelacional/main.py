# SQL_ALCHEMY
# Permite a conexão da API com o banco de dados
# Flask permite uma criação de API com python
# Response e Request -> Requisição

from flask import Flask, Response, request
from flask_sqlalchemy import SQLAlchemy
import json

app = Flask('carros')

# Rastrear as modificações realizadas
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False # Recomenda-se False para melhor performance
# Configuração de conexão com o Banco
# $40 -> Faz o papel do @
# 1 - Usuário (root) 2- Senha (senai%40134) 3- localhost (127.0.0.1) 4 - nome do Banco
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Senai%40134@127.0.0.1/db_carro'

mydb = SQLAlchemy(app)

# Classe para definir o modelo dos dados que correspondem a tabela do banco de dados 
class Carros (mydb.Model):
    __tablename__ = 'tb_carro'
    id_carro = mydb.Column(mydb.Integer, primary_key=True)
    marca = mydb.Column(mydb.String(255))
    modelo = mydb.Column(mydb.String(255))
    ano = mydb.Column(mydb.String(255))
    cor = mydb.Column(mydb.String(255))
    valor = mydb.Column(mydb.String(255))
    numero_Vendas = mydb.Column(mydb.String(255))

    # Esse metodo to_json vai ser usado para converter o objeto em Json
    def to_json(self):
        return {
            'id_carro': self.id_carro,
            'marca': self.marca,
            'modelo': self.modelo,
            'ano': self.ano,
            'cor': self.cor,
            'valor': float(self.valor),
            'numero_Vendas': self.numero_Vendas
        }
    
# ------------------------------------------------------------------------------------
# RESPOSTA PADRÃO
def gera_resposta(status, conteudo, mensagem=False):
    body = {}
    body['dados'] = conteudo # Mudei o nome da chave para ser mais genérico
    if (mensagem):
        body['mensagem'] = mensagem
    return Response(json.dumps(body), status=status, mimetype='application/json')

# ------------------------------------------------------------------------------------
# METODO GET (TODOS)
@app.route('/carros', methods=['GET'])
def seleciona_carro():
    carro_selecionado = Carros.query.all()
    carro_json = [carro.to_json() for carro in carro_selecionado]
    return gera_resposta(200, carro_json, "Lista de Carros")

# -------------------------------------------------------------------------------------
# METODO GET (POR ID)
@app.route('/carro/<id_carro_pam>', methods=['GET'])
def seleciona_carro_id(id_carro_pam):
    carro_selecionado = Carros.query.filter_by(id_carro=id_carro_pam).first()
    
    if not carro_selecionado:
        return gera_resposta(404, {}, "Carro não encontrado")

    carro_json = carro_selecionado.to_json()
    return gera_resposta(200, carro_json, 'Carro encontrado')

# -------------------------------------------------------------------------------------
# METODO POST 
@app.route('/carros', methods=['POST'])
def criar_carro():
    requisicao = request.get_json()
    try:
        carro = Carros(
            marca = requisicao['marca'],
            modelo = requisicao['modelo'],
            ano = requisicao['ano'],
            cor = requisicao['cor'],
            valor = requisicao['valor'],
            numero_Vendas = requisicao['numero_Vendas']
        )
        mydb.session.add(carro)
        mydb.session.commit()
        return gera_resposta(201, carro.to_json(), 'Criado com Sucesso')
    except Exception as e:
        print('Erro', e)
        return gera_resposta(400, {}, "Erro ao Cadastrar!")
    
# -------------------------------------------------------------------------------------
# METODO DELETE
@app.route('/carros/<id_carro_pam>', methods=['DELETE']) # ROTA CORRIGIDA
def deleta_carro(id_carro_pam):
    carro = Carros.query.filter_by(id_carro=id_carro_pam).first()

    if not carro:
        return gera_resposta(404, {}, "Carro não encontrado")

    try:
        mydb.session.delete(carro)
        mydb.session.commit()
        return gera_resposta(200, carro.to_json(), 'Deletado com Sucesso')
    except Exception as e:
        print('Erro', e)
        return gera_resposta(400, {}, "Erro ao Deletar")

# --------------------------------------------------------------------------
# METODO update
@app.route("/carros/<id_carro_pam>", methods=['PUT'])
def atualiza_carro(id_carro_pam):
    carro = Carros.query.filter_by(id_carro=id_carro_pam).first()
    requisicao = request.get_json()

    try:
        if ('marca' in requisicao):
            carro.marca = requisicao['marca']

        if ('modelo' in requisicao):
            carro.modelo = requisicao['modelo']

        if ('ano' in requisicao):
            carro.ano = requisicao['ano']

        if ('cor' in requisicao):
            carro.cor = requisicao['cor']
    
        if ('valor' in requisicao):
            carro.valor = requisicao['valor']

        if ('numero_Vendas' in requisicao):
            carro.numero_Vendas = requisicao['numero_Vendas']

        mydb.session.add(carro)
        mydb.session.commit()
        return gera_resposta(200, carro.to_json(), 'Carro Atualizado com Sucesso')
    except Exception as e:
        print('Erro', e)
        return gera_resposta(400, {}, "Erro ao Atualizar")

# -------------------------------------------------------------------------------------

if __name__ == '__main__':
    app.run(port=5000, host='localhost', debug=True)